public class Kodu5c {
//kommentaare ei oodata, need v�ib kustutada
	public static int[][] summad(int n){
		return null;
	}

	public static String[] rongid(int n){
		return null;
	}

}//Kodu5c
